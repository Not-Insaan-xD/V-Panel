from flask import Flask, jsonify, render_template
import psutil, time

app = Flask(__name__)

@app.route("/")
def dashboard():
    return render_template("index.html")

@app.route("/api/stats")
def stats():
    return jsonify({
        "cpu": psutil.cpu_percent(interval=0.5),
        "ram": psutil.virtual_memory().percent,
        "disk": psutil.disk_usage('/').percent,
        "load": psutil.getloadavg()[0],
        "uptime": int(time.time() - psutil.boot_time())
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=16720)
